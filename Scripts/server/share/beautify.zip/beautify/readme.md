# Straship automatic installer

Just execute the beautify.sh file from home directory of the user with superuser privileges and let it do its work.

# Commands

From Home directory of user run the following in terminal:

``` sudo sh beautify/install.sh ```

# Author

## Synergy Syndicate
