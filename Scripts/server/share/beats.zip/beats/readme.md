# Beats automatic installer

Move the beats folder to the home directory of a user and then execute the setup.sh with superuser privileges.

# Commands

From Home directory of user run the following in terminal:

``` sudo sh beats/setup.sh ```

# Author

## Synergy Syndicate